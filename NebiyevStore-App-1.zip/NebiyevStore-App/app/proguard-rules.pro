# NəbiyevStore ProGuard Rules
-keep class az.nebiyev.store.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
-keepattributes *Annotation*
